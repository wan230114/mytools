#!/usr/bin/env python3
# %%
import sys
import os
from matplotlib import pyplot as plt
from venn import venn
# from matplotlib_venn import venn3
# pip install matplotlib
# pip install matplotlib_venn

# fi1_name, fi2_name = "merge_H3K27me3_YJ-A549-3-0uM--VS--YJ-A549-NC_filter_DOWN.genelist", "merge_H3K27me3_YJ-3-0--VS--YJ-NC_filter_DOWN.genelist"
fi1_name, fi2_name, fi3_name = sys.argv[1:4]
# fi1_name, fi2_name, fi3_name = ['A', 'B', 'C']
# out1, out2, out3 = fi1_name, fi2_name, fi3_name
out1 = os.path.splitext(os.path.basename(fi1_name))[0]
out2 = os.path.splitext(os.path.basename(fi2_name))[0]
out3 = os.path.splitext(os.path.basename(fi3_name))[0]

Outname = out1 + '--VS--' + out2 + '--VS--' + out3

# %%  write file
with open(fi1_name) as fi1, open(fi2_name) as fi2, open(fi3_name) as fi3:
    s1 = {x.strip().strip('"') for x in fi1.readlines()}
    s2 = {x.strip().strip('"') for x in fi2.readlines()}
    s3 = {x.strip().strip('"') for x in fi3.readlines()}

with open(Outname + '__union1-A' + '.txt', 'w') as fo:
    union_A = s1
    fo.write('\n'.join(sorted(union_A))+"\n")
with open(Outname + '__union2-B' + '.txt', 'w') as fo:
    union_B = s2
    fo.write('\n'.join(sorted(union_B))+"\n")
with open(Outname + '__union3-C' + '.txt', 'w') as fo:
    union_C = s3
    fo.write('\n'.join(sorted(union_C))+"\n")
with open(Outname + '__union0-A-B-C' + '.txt', 'w') as fo:
    union_A_B_C = s1 | s2 | s3
    fo.write('\n'.join(sorted(union_A_B_C))+"\n")

# %%
with open(Outname + '__diff1-A' + '.txt', 'w') as fo:
    diff_A = s1 - s2 - s3
    fo.write('\n'.join(sorted(diff_A))+"\n")
with open(Outname + '__diff2-B' + '.txt', 'w') as fo:
    diff_B = s2 - s1 - s3
    fo.write('\n'.join(sorted(diff_B))+"\n")
with open(Outname + '__diff3-C' + '.txt', 'w') as fo:
    diff_C = s3 - s1 - s2
    fo.write('\n'.join(sorted(diff_C))+"\n")
with open(Outname + '__diff0-A-B-C' + '.txt', 'w') as fo:
    diff_A_B_C = diff_A | diff_B | diff_C
    fo.write('\n'.join(sorted(diff_A_B_C))+"\n")

with open(Outname + '__comm1-A-B' + '.txt', 'w') as fo:
    comm_A_B = s1 & s2
    fo.write('\n'.join(sorted(comm_A_B))+"\n")
with open(Outname + '__comm2-A-C' + '.txt', 'w') as fo:
    comm_A_C = s1 & s3
    fo.write('\n'.join(sorted(comm_A_C))+"\n")
with open(Outname + '__comm3-B-C' + '.txt', 'w') as fo:
    comm_B_C = s2 & s3
    fo.write('\n'.join(sorted(comm_B_C))+"\n")
with open(Outname + '__comm0-A-B-C' + '.txt', 'w') as fo:
    comm_A_B_C = s1 & s2 & s3
    fo.write('\n'.join(sorted(comm_A_B_C))+"\n")

# print(sorted(union_A_B_C))
# print(sorted(comm_A_B_C))
# print(sorted(diff_A))
# print(sorted(diff_B))
# print(sorted(diff_C))

# %%  plot venn
# help(venn2)
anno0 = '%s(%s) vs %s(%s) vs %s(%s)' % (
    "A", len(s1), "B", len(s2), "C", len(s3))

# 'Comm/A: %.2f%%; Comm/B: %.2f%%; Comm/C: %.2f%%; \n'
# len(comm_A_B_C)/len(s1)*100 if len(s1) > 0 else 0,
# len(comm_A_B_C)/len(s2)*100 if len(s2) > 0 else 0,
# len(comm_A_B_C)/len(s3)*100 if len(s2) > 0 else 0
anno = (
    'Union(ALL): %s\n' % (len(union_A_B_C)) +
    'Comm: %s (Comm/Union: %.2f%%) (A_B: %s  B_C: %s  A_C: %s)\n' % (
        len(comm_A_B_C),
        len(comm_A_B_C)/len(union_A_B_C)*100,
        len(comm_A_B),
        len(comm_B_C),
        len(comm_A_C),
    ) +
    'Diff: %s (A:%s B:%s C:%s) (Diff/Union: %.2f%%);\n' % (
        len(diff_A_B_C),
        len(diff_A),
        len(diff_B),
        len(diff_C),
        len(diff_A_B_C)/len(union_A_B_C)*100,
    ) +
    'A: %s \nB: %s \nC: %s' % (out1, out2, out3))
print(anno0 + '\n' + anno, file=open('%s__venn.doc.txt' % Outname, 'w'))
plt.title(anno0)
plt.text(0, -1.1, anno, ha='center', ma='left')
for x in [
        list("rgb"), list("rgy"), list("byg"),
        'Accent', 'Accent_r', 'Blues', 'Blues_r', 'BrBG', 'BrBG_r', 'BuGn', 'BuGn_r', 'BuPu', 'BuPu_r', 'CMRmap', 'CMRmap_r', 'Dark2', 'Dark2_r', 'GnBu', 'GnBu_r', 'Greens', 'Greens_r', 'Greys', 'Greys_r', 'OrRd', 'OrRd_r', 'Oranges', 'Oranges_r', 'PRGn', 'PRGn_r', 'Paired', 'Paired_r', 'Pastel1', 'Pastel1_r', 'Pastel2', 'Pastel2_r', 'PiYG', 'PiYG_r', 'PuBu', 'PuBuGn', 'PuBuGn_r', 'PuBu_r', 'PuOr', 'PuOr_r', 'PuRd', 'PuRd_r', 'Purples', 'Purples_r', 'RdBu', 'RdBu_r', 'RdGy', 'RdGy_r', 'RdPu', 'RdPu_r', 'RdYlBu', 'RdYlBu_r', 'RdYlGn', 'RdYlGn_r', 'Reds', 'Reds_r', 'Set1', 'Set1_r', 'Set2', 'Set2_r', 'Set3', 'Set3_r', 'Spectral', 'Spectral_r', 'Wistia', 'Wistia_r', 'YlGn', 'YlGnBu', 'YlGnBu_r', 'YlGn_r', 'YlOrBr', 'YlOrBr_r', 'YlOrRd', 'YlOrRd_r', 'afmhot', 'afmhot_r', 'autumn', 'autumn_r', 'binary', 'binary_r', 'bone', 'bone_r', 'brg', 'brg_r', 'bwr', 'bwr_r', 'cividis', 'cividis_r', 'cool', 'cool_r', 'coolwarm', 'coolwarm_r', 'copper', 'copper_r', 'cubehelix', 'cubehelix_r', 'flag', 'flag_r', 'gist_earth', 'gist_earth_r', 'gist_gray', 'gist_gray_r', 'gist_heat', 'gist_heat_r', 'gist_ncar', 'gist_ncar_r', 'gist_rainbow', 'gist_rainbow_r', 'gist_stern', 'gist_stern_r', 'gist_yarg', 'gist_yarg_r', 'gnuplot', 'gnuplot2', 'gnuplot2_r', 'gnuplot_r', 'gray', 'gray_r', 'hot', 'hot_r', 'hsv', 'hsv_r', 'inferno', 'inferno_r', 'jet', 'jet_r', 'magma', 'magma_r', 'nipy_spectral', 'nipy_spectral_r', 'ocean', 'ocean_r', 'pink', 'pink_r', 'plasma', 'plasma_r', 'prism', 'prism_r', 'rainbow', 'rainbow_r', 'seismic', 'seismic_r', 'spring', 'spring_r', 'summer', 'summer_r', 'tab10', 'tab10_r', 'tab20', 'tab20_r', 'tab20b', 'tab20b_r', 'tab20c', 'tab20c_r', 'terrain', 'terrain_r', 'twilight', 'twilight_r', 'twilight_shifted', 'twilight_shifted_r', 'viridis', 'viridis_r', 'winter', 'winter_r'
]:
    # def venn_dispatch(data, func, fmt="{size}", hint_hidden=False, cmap="viridis", alpha=.4, figsize=(8, 8), fontsize=13, legend_loc="upper right", ax=None):
    venn({out1: s1, out2: s2, out3: s3},
         fmt="{percentage:.1f}%\n({size})",
         #   alpha=.5,
         #  cmap=["r", "g", "b"]
         #  cmap="Accent"
         #  cmap="Set2"  # 蓝 绿 紫
         #  cmap="Set3"  # 蓝 绿 黄
         cmap=x  # 蓝 绿 黄
         )
    # venn3(subsets=[s1, s2, s3], set_labels=(
    #     "A", "B", "C"), set_colors=('r', 'b', 'g'))
    # venn2(subsets=[s1, s2])  #, set_labels=(out1, out2), set_colors=('r', 'g'))

    # %%
    # plt.savefig('%s__venn.pdf' % Outname, dpi=200, bbox_inches='tight')
    plt.savefig('%s__venn.png' % (Outname + "_" + ''.join(x)),
                dpi=200, bbox_inches='tight')
    # plt.savefig('%s__venn.svg' % Outname, dpi=200, bbox_inches='tight')
    plt.close()