package pply;

use strict;
use Exporter;

use vars qw($VERSION @ISA @EXPORT @EXPORT_OK %EXPORT_TAGS);

$VERSION	= 1.00;
@ISA		= qw(Exporter);
@EXPORT		= qw(abspath region_merge run_cmd parse_config);
@EXPORT_OK  = qw();
%EXPORT_TAGS= (
	DEFAULT => [qw()],
	Both	=> [qw()]
);

sub abspath {  
	my ($path) = @_;  
	$path =~ s/^~/$ENV{HOME}/;
	$path = File::Spec->rel2abs($path);
	my $newpath;  
	do {  
		$newpath = $path;  
		$path =~ s|[^/][^/]*\/\.\.\/||;  
	} while $newpath ne $path;  
	return $newpath;  
}

sub region_merge{
	my @region = @_;
	my (@overlap,@merge,$last);
	for(sort {$a->[0]<=>$b->[0] || $a->[1]<=>$b->[1]} @region){
		if(defined $last && $last < $_->[0]){ # no overlap
			@overlap = sort {$a<=>$b} @overlap;
			push @merge,[@overlap[0,-1]];
			@overlap = ();
			$last = $_->[1];
		}else{
			$last = (defined $last && $last > $_->[1]) ? $last : $_->[1];
		}
		push @overlap,@$_;
	}
	@overlap = sort {$a<=>$b} @overlap;
	push @merge,[@overlap[0,-1]];
	return @merge;
}

sub run_cmd{
    my ($cmd,$fname,$cmdonly) = @_;
	my $cmd_f = '';
	for(split /\n/,$cmd){
		if(/^\s*#/ || /^\s*$/ || /^\s*cd\s*\S*\s*$/){
			$cmd_f .= "$_\n"
		}else{
			$cmd_f .= "[ \$? == 0 ] && ($_)\n";
		}
	}
	$cmd_f .= "[ \$? == 0 ] && echo CMD_DONE\n";

    open FLS,">$fname" or die 'Error: write cmd $fname error\n';
    print FLS $cmd_f;
    close FLS;
    system ("sh $fname") unless(defined $cmdonly && $cmdonly);
}

sub parse_config{
	my $conifg_file = shift;
	my $config_p = shift;                               
	my $error_status = 0;
	open IN,$conifg_file || die "fail open: $conifg_file";
	while (<IN>) {
	  next if (/^#/);
	  if (/(\S+)\s*=\s*(\S+)/) {
		 my ($software_name,$software_address) = ($1,$2);
		 $config_p->{$software_name} = $software_address;
		 if (! -e $software_address){
		   warn "$software_name && $software_address is not exists\n";
		   $error_status = 1;
		 }
	   }
	}
	close IN;
	die "\nExit due to error of software config\n" if($error_status);
}

1;

