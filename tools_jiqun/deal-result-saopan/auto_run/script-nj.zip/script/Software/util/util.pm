package util;

use strict;
use Exporter;

use vars qw($VERSION @ISA @EXPORT @EXPORT_OK %EXPORT_TAGS);

$VERSION	= 1.00;
@ISA		= qw(Exporter);
@EXPORT		= qw(abspath region_merge run_cmd);
@EXPORT_OK  = qw();
%EXPORT_TAGS= (
	DEFAULT => [qw()],
	Both	=> [qw()]
);

sub abspath {  
	my ($path) = @_;  
	$path =~ s/^~/$ENV{HOME}/;
	$path = File::Spec->rel2abs($path);
	my $newpath;  
	do {  
		$newpath = $path;  
		$path =~ s|[^/][^/]*\/\.\.\/||;  
	} while $newpath ne $path;  
	return $newpath;  
}

sub region_merge{
	my @region = @_;
	if(@region == 0){
		return ();
	}
	my (@overlap,@merge,$last);
	for(sort {$a->[0]<=>$b->[0] || $a->[1]<=>$b->[1]} @region){
		if(defined $last && $last < $_->[0]){ # no overlap
			@overlap = sort {$a<=>$b} @overlap;
			push @merge,[@overlap[0,-1]];
			@overlap = ();
			$last = $_->[1];
		}else{
			$last = (defined $last && $last > $_->[1]) ? $last : $_->[1];
		}
		push @overlap,@$_;
	}
	@overlap = sort {$a<=>$b} @overlap;
	push @merge,[@overlap[0,-1]];
	return @merge;
}

sub run_cmd{
    my ($cmd,$fname,$cmdonly) = @_;
    open FLS,">$fname" or die 'Error: write cmd $fname error\n';
    print FLS $cmd;
    close FLS;
    system ("sh $fname") unless(defined $cmdonly && $cmdonly);
}

1;

