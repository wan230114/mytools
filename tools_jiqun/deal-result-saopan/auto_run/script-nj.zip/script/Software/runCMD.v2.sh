#!/bin/bash
#########################################################################
# File Name: runCMD.sh
# Author: leiyang
# mail: leiyang@novogene.com
# Created Time: Wed 14 Sep 2016 12:04:36 PM CST
#########################################################################


if [ ! -n "$1" ]
then
	echo -e "Help:\n\t$0 CMDFILE\n\t$0 CMDFILE 1\n\t$0 CMDFILE 5 nosafe\n"
	exit 0
fi



line=$2

if [ ! -n "$line" ]
then
	line=1
fi

NoSafeEcho=
nosafetag=
if [ -n "$3" ] && [ $3 == "nosafe" ]
then
	NoSafeEcho="; echo '[nosafe !!!]'"
	nosafetag="[nosafe]"
fi

echo "HOSTNAME: "$HOSTNAME
echo `date +"%Y-%m-%d %H:%M:%S"` '[start]'
awk -v startID=$SGE_TASK_ID -v IDlen=$line  -v nosafe="$NoSafeEcho" -v nosafetag="$nosafetag" 'NR>=startID { count++;print "("$_ nosafe") && echo `date +\"%Y-%m-%d %H:%M:%S\"` [work."NR" complete]"nosafetag; if(count==IDlen){exit}}' $1 | /bin/bash
echo `date +"%Y-%m-%d %H:%M:%S"` '[finish]'

