#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
从存储上扫描文件
"""
import os
import sys
import subprocess
import re
import configparser
import logging
import argparse
import enum
import time
from string import Template
from collections import defaultdict

__all__ = ['ConfigParser']

logging.basicConfig(level=logging.DEBUG,
                    format='%(asctime)s - %(name)s - %(funcName)s- %(lineno)d -'
                           '%(levelname)s - %(message)s')
_logger = logging.getLogger('main')


@enum.unique
class CfgFileSection(enum.Enum):
    """
    配置文件里section的名称字面值
    """
    root_section_name = 'root'
    root_section_name_path_node = 'path'

    peo_section_name = 'peo'
    pipeline_section_name = 'pipeline'

    projects_section_name = 'Projects'
    projects_section_gwas_node_name = 'gwas'
    projects_section_bsa_node_name = 'bsa'
    projects_section_pop_node_name = 'population'
    projects_section_var_node_name = 'variation'
    projects_section_genetic_map_node_name = 'geneticmap'

    not_serving_section_name = 'not serving'

    scan_section_name = 'scan'
    scan_section_results_file_node_name = 'scan_results_file'
    scan_section_search_path_node_name = 'search_path_node'
    scan_section_template_node_name = 'scan_file_template'
    scan_section_formatted_cmd_node_name = 'formatted_origin_scan_results_cmd'

    out_put_section_name = 'output'
    out_put_section_path_node_name = 'out_path'
    out_put_section_bin_path_node_name = 'bin_path'
    out_put_section_scan_bin_path_node_name = 'scan_bin_dir'
    out_put_section_stat_size_bin_path_node_name = 'stat_size_bin_dir'
    out_put_section_stat_clean_bin_path_node_name = 'stat_clean_bin_dir'
    out_put_section_origin_scan_results_node_name = 'origin_scan_results_dir'
    out_put_section_formatted_scan_results_node_name = 'formatted_scan_results_dir'
    out_put_section_type_origin_scan_results_node_name = 'type_origin_scan_results_dir'
    out_put_section_type_formatted_scan_results_node_name = 'type_formatted_scan_results_dir'
    out_put_section_stat_size_node_name = 'stat_size_results'
    out_put_section_stat_clean_node_name = 'stat_clean_results'

    qsub_section_name = 'qsub'
    qsub_section_qsub_cmd_node_name = 'qsub_cmd'
    qsub_section_qsub_shell_path_node_name = 'shell_file_path'


class ConfigParser(object):
    def __init__(self, cfg_file):
        self.__cfg_file = cfg_file
        self.__out_path = ''
        self.__out_put_section = None
        self.__in_file = ''
        self.__users = ''
        self.__time = ''
        self.__qsub_cmd_template = ''
        self.__qsub_shell_path = ''
        self.__path_type_dict = defaultdict(list)
        self.__cfg_file_info_obj = []
        self.__search_path_node_name_list = []
        self.__scan_template = []
        self.__scan_results_template = ''
        self.__formatted_cmd_template = ''

    @staticmethod
    def __get_search_path_from_cmd(cmd):
        if cmd.find("'") == -1:
            return cmd
        cmd = ConfigParser.clean_value(cmd)
        paths = None
        try:
            paths = subprocess.check_output(cmd, shell=True)
        except subprocess.CalledProcessError as e:
            _logger.warn('%s run error' % cmd)
            paths = []
        else:
            try:
                paths = paths.decode('utf-8').strip('\n').split('\n')
            except UnicodeEncodeError as e:
                _logger.warn('UnicodeEncodeError for path utf-8 decode:%s' % paths)
            except Exception as e:
                _logger.warn('unknown error for path utf-8 decode: %s\n%s' % (paths, repr(e)))

        return paths

    def __get_search_path_in_section(self, section_obj):
        path_list = []
        for node in self.__cfg_file_info_obj[section_obj]:
            if self.__cfg_file_info_obj[section_obj][node] == '':#node本身是目录名
                try:
                    search_path = os.path.join(
                        self.__path_type_dict[CfgFileSection.root_section_name.value][0], node)
                    self.__path_type_dict[section_obj].append(search_path)
                except Exception as e:
                    pass
            else:
                tmp_path_list = [self.__get_search_path_from_cmd(x)
                                 for x in self.__cfg_file_info_obj[section_obj][node].split(',')]
                for item in tmp_path_list:
                    if isinstance(item, list):
                        path_list.extend(item)
                    else:
                        path_list.append(item)

        self.__path_type_dict[section_obj].extend(path_list)

    def __get_search_path_node_name(self, scan_section):
        search_path_nodes = scan_section[CfgFileSection.scan_section_search_path_node_name.value]
        for item in search_path_nodes.split(','):
            self.__search_path_node_name_list.append(self.clean_value(item))

    def __get_search_path(self):
        scan_type_secion = self.__cfg_file_info_obj[CfgFileSection.scan_section_name.value]
        self.__get_search_path_node_name(scan_type_secion)

        for section in self.__cfg_file_info_obj:
            if section not in self.__search_path_node_name_list:
                _logger.info('%s section ignored when get searched path' % section)
            else:
                self.__get_search_path_in_section(section)

    def __get_scan_template(self):
        scan_section = self.__cfg_file_info_obj[CfgFileSection.scan_section_name.value]
        self.__scan_template = scan_section[CfgFileSection.scan_section_template_node_name.value]
        self.__scan_template = ConfigParser.clean_value(self.__scan_template)
        self.__scan_results_template = scan_section[
            CfgFileSection.scan_section_results_file_node_name.value]
        self.__formatted_cmd_template = scan_section[
            CfgFileSection.scan_section_formatted_cmd_node_name.value]

    def __get_qsub_template(self):
        """
        获取qsub节点的内容
        """
        qsub_cmd_section = self.__cfg_file_info_obj[CfgFileSection.qsub_section_name.value]
        self.__qsub_cmd_template = qsub_cmd_section[
            CfgFileSection.qsub_section_qsub_cmd_node_name.value]
        self.__qsub_shell_path = qsub_cmd_section[
            CfgFileSection.qsub_section_qsub_shell_path_node_name.value]
        self.__qsub_cmd_template = ConfigParser.clean_value(self.__qsub_cmd_template)
        self.__qsub_shell_path = ConfigParser.clean_value(self.__qsub_shell_path)

    @staticmethod
    def clean_value(value):
        '''
        由于可能先有空格，或者先有'，所以同一个语句执行了两遍
        :param value:
        :return:
        '''
        value = value.strip("'").strip(' ')
        value = value.strip("'").strip(' ')
        return value

    def parser_file(self):
        self.__cfg_file_info_obj = configparser.ConfigParser(
            interpolation=configparser.ExtendedInterpolation()
        )
        self.__cfg_file_info_obj.read(self.__cfg_file)
        if self.__cfg_file_info_obj is []:
            _logger.warn('no info in arguments setup file: {cfg_file_path}'
                         .format(cfg_file_path=self.__cfg_file))
            return

        self.__out_put_section = self.__cfg_file_info_obj[
            CfgFileSection.out_put_section_name.value]

        self.__out_path = self.__out_put_section[
            CfgFileSection.out_put_section_path_node_name.value]
        self.__out_path = os.path.abspath(self.__out_path)
        self.__out_put_section[
            CfgFileSection.out_put_section_path_node_name.value] = self.__out_path

        self.__get_search_path()
        self.__get_scan_template()
        self.__get_qsub_template()

    def __print_searched_path(self):
        print_str_list = []
        print_str_t = Template('searched path in "${type_name}": ${searched_str}')
        for path_type in self.__path_type_dict:
            if path_type == 'root':
                continue
        if path_type and path_type in self.__path_type_dict:
            print_str = print_str_t.substitute(type_name=path_type,
                                               searched_str=repr(
                                                   ' '.join(self.__path_type_dict[path_type])))
            print_str_list.append(print_str)
        if print_str_list:
            return '\n'.join(print_str_list)
        else:
            return ""

    def all_out_path(self):
        """
        遍历[output]一节的所有输出路径
        """
        for one_path in self.__out_put_section.values():
            yield one_path

    @property
    def path_dict(self):
        return self.__path_type_dict

    @property
    def out_path(self):
        return self.__out_path

    @property
    def searched_type(self):
        return self.__search_path_node_name_list

    @property
    def scan_template(self):
        return self.__scan_template

    @property
    def scan_results_template(self):
        return self.__scan_results_template

    @property
    def formatted_cmd_template(self):
        return self.__formatted_cmd_template

    @property
    def qsub_template(self):
        return self.__qsub_cmd_template

    @property
    def qsub_shell_path(self):
        return self.__qsub_shell_path

    @property
    def bin_dir(self):
        bin_dir = self.__out_put_section[CfgFileSection.out_put_section_bin_path_node_name.value]
        return bin_dir

    @property
    def scan_bin_dir(self):
        scan_bin_dir = self.__out_put_section[
            CfgFileSection.out_put_section_scan_bin_path_node_name.value]
        return scan_bin_dir

    @property
    def stat_size_bin_dir(self):
        stat_size_bin_dir = self.__out_put_section[
            CfgFileSection.out_put_section_stat_size_bin_path_node_name.value]
        return stat_size_bin_dir

    @property
    def stat_clean_bin_dir(self):
        stat_clean_bin_dir = self.__out_put_section[
            CfgFileSection.out_put_section_stat_clean_bin_path_node_name.value]
        return stat_clean_bin_dir

    @property
    def scan_results_dir(self):
        scan_results_dir = self.__out_put_section[
            CfgFileSection.out_put_section_bin_scan_results_node_name.value]
        return scan_results_dir

    @property
    def stat_size_dir(self):
        stat_size_dir = self.__out_put_section[
            CfgFileSection.out_put_section_bin_stat_size_node_name.value]
        return stat_size_dir

    @property
    def stat_clean_dir(self):
        stat_clean_dir = self.__out_put_section[
            CfgFileSection.out_put_section_bin_stat_clean_node_name.value]
        return stat_clean_dir

    @property
    def type_origin_dir(self):
        """
        shell扫描结果存放路径模板
        """
        the_path_model = self.__out_put_section[
            CfgFileSection.out_put_section_type_origin_scan_results_node_name.value]
        return the_path_model

    @property
    def type_formatted_dir(self):
        """
        shell扫描结果格式转换后存放的路径模板
        """
        the_path_model = self.__out_put_section[
            CfgFileSection.out_put_section_type_formatted_scan_results_node_name.value]
        return the_path_model

    def __str__(self):
        return self.__print_searched_path()

    def __repr__(self):
        self.__print_searched_path()


class ShellCreator(object):
    def __init__(self, cfg_file_parser):
        self.__cfg_file_parser = cfg_file_parser
        self.__out_path = os.path.abspath(cfg_file_parser.out_path)
        self.__cmd_dict = defaultdict(list)
        self.__shell_file_path_dict = defaultdict(list)
        self.__path_dup_check_dict = defaultdict(str)
        self.__list_file_path = None
        self.__type_bin_path_dict = {}
        self.__type_origin_path_dict = {}
        self.__type_formatted_path_dict = {}
        self.__origin_results_dict = defaultdict(list)
        #self.__type_formatted_cmd_dict = defaultdict(list)

    @staticmethod
    def __create_path(one_path):
        """
        新建路径
        """
        if not os.path.exists(one_path):
            try:
                os.makedirs(one_path)
            except PermissionError:
                _logger.fatal('have no permission to create {}'.format(one_path))
                exit(-1)

    def __create_path_for_shell(self):
        """
        建立扫描流程中需要的各种路径
        这些路径是在配置文件里[output]一节配置的
        """
        for one_path in self.__cfg_file_parser.all_out_path():
            if one_path.find('$') == -1:
                ShellCreator.__create_path(one_path)
                #print('one_path:{}'.format(one_path))

        the_path_model_of_origin = Template(self.__cfg_file_parser.type_origin_dir)
        the_path_model_of_formatted = Template(self.__cfg_file_parser.type_formatted_dir)
        for one_type in self.__cfg_file_parser.searched_type:
            if not one_type or one_type == 'root':
                continue
            original_path = the_path_model_of_origin.substitute(results_type_dir=one_type)
            formatted_path = the_path_model_of_formatted.substitute(results_type_dir=one_type)
            #print('one_type:{}'.format(one_type))
            #print('original_path:{}'.format(original_path))
            self.__type_origin_path_dict[one_type] = original_path
            self.__type_formatted_path_dict[one_type] = formatted_path
            ShellCreator.__create_path(original_path)
            ShellCreator.__create_path(formatted_path)

    def __create_shell_cmd(self):
        scan_cmd_template = Template(self.__cfg_file_parser.scan_template)
        path_type_dict = self.__cfg_file_parser.path_dict
        search_type = self.__cfg_file_parser.searched_type
        scan_results_template = Template(self.__cfg_file_parser.scan_results_template)
        formatted_cmd_template = Template(self.__cfg_file_parser.formatted_cmd_template)

        for type_name in search_type:
            if type_name == 'root':
                continue
            for item in path_type_dict[type_name]:
                path_name = os.path.basename(item.rstrip('/'))
                scan_results_file = scan_results_template.substitute(
                    results_type_dir=type_name, results_file_name=path_name)
                scan_cmd_str = scan_cmd_template.substitute(search_path=item,
                                                            results_type_dir=type_name,
                                                            results_file_name=path_name)
                formatted_cmd_str = formatted_cmd_template.substitute(
                    scan_results_file=scan_results_file, results_type_dir=type_name,
                    file_name=path_name)
                cmd_str = '\n'.join([scan_cmd_str, formatted_cmd_str])
                self.__cmd_dict[type_name].append([cmd_str, path_name])
                self.__origin_results_dict[type_name].append(scan_results_file)
                #self.__type_formatted_cmd_dict[type_name].append(formatted_cmd_str)
                if cmd_str not in self.__path_dup_check_dict:
                    self.__path_dup_check_dict[cmd_str] = ''
                else:
                    pass

    def __write_shell_cmd(self):
        for type_name in self.__cmd_dict:
            type_name_as_prefix = re.sub(r'\s+', '_', type_name)
            bin_path = os.path.join(self.__cfg_file_parser.scan_bin_dir,
                                    type_name_as_prefix)
            if not os.path.exists(bin_path):
                os.makedirs(bin_path)
            else:
                print('already exits')
            self.__type_bin_path_dict[type_name] = bin_path

            name_index = 1
            for cmd_info in self.__cmd_dict[type_name]:
                shell_file_name = '_'.join([type_name_as_prefix, cmd_info[1],
                                            str(name_index)])
                name_index += 1
                shell_file_path = os.path.join(bin_path, shell_file_name)
                with open(shell_file_path, 'w') as fh:
                    fh.write(cmd_info[0]+'\n')
                shell_run_cmd = ''.join(['sh ', os.path.abspath(shell_file_path)])
                self.__shell_file_path_dict[type_name].append(shell_run_cmd)

    def __write_shell_files_list_file(self):
        list_file_name = ''.join(['shell_file_list',
                                  time.strftime("%Y_%m_%d__%H_%M_%S",
                                                time.localtime())])
        list_file_path = os.path.join(self.__cfg_file_parser.scan_bin_dir,
                                      list_file_name)
        with open(list_file_path, 'w') as fh:
            for type_name in self.__shell_file_path_dict:
                fh.writelines([x+'\n' for x in
                               self.__shell_file_path_dict[type_name]])

        self.__list_file_path = os.path.abspath(list_file_path)

    def __write_qsub_shell_cmd(self):
        """
        生成投递脚本
        """
        shell_file_path = self.__cfg_file_parser.qsub_shell_path
        qsub_cmd = self.__cfg_file_parser.qsub_template
        qsub_shell_file = shell_file_path

        with open(qsub_shell_file, 'w') as file_handle:
            cmd = ' '.join([qsub_cmd, self.__list_file_path, '\n'])
            file_handle.write(cmd)

    def __write_origin_shell_results_list(self):
        """
        生成origin scan results file list
        """
        for type_name, files_list in self.__origin_results_dict.items():
            this_type_original_results_path = self.__type_origin_path_dict[type_name]
            this_type_original_results_name = 'results.lst'
            this_type_original_results = os.path.join(this_type_original_results_path,
                                                      this_type_original_results_name)
            with open(this_type_original_results, 'w') as fh:
                info = '\n'.join(files_list)
                fh.write(info)

    def create(self):
        self.__create_path_for_shell()
        self.__create_shell_cmd()
        self.__write_shell_cmd()
        self.__write_shell_files_list_file()
        self.__write_qsub_shell_cmd()
        self.__write_origin_shell_results_list()


def main():
    cfg_file = init_args()
    cfg_file_parser = ConfigParser(cfg_file)
    cfg_file_parser.parser_file()
    shell_creator = ShellCreator(cfg_file_parser)
    shell_creator.create()
    print('shell_creating done')


def init_args():
    app_path = 'python %s' % os.path.abspath(sys.argv[0])
    parser = argparse.ArgumentParser(prog=app_path, description='get files info at paths.')
    parser.add_argument('--cfg', help='arguments setup file', required=True)
    args = parser.parse_args()

    cfg_file = os.path.abspath(args.cfg)

    if os.path.isfile(cfg_file) is False:
        _logger.fatal('no available arguments setup file, '
                      'please check the path: {cfg_file_path}'
                      .format(cfg_file_path=cfg_file))
        sys.exit(1)

    return cfg_file

if __name__ == '__main__':
    main()
