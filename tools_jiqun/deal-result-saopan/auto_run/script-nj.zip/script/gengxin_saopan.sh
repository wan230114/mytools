/NJPROJ2/Plant/zhangwenlin/Cluster_management/saopan/script/updateScanResult.sh /NJPROJ2/Plant/Saopan_result/NJPROJ2_10M /NJPROJ2/Plant/Saopan_result/
/NJPROJ2/Plant/zhangwenlin/Cluster_management/saopan/script/updateScanResult.sh /NJPROJ2/Plant/Saopan_result/NJPROJ3_10M /NJPROJ2/Plant/Saopan_result/
/NJPROJ2/Plant/zhangwenlin/Cluster_management/saopan/script/updateScanResult.sh /NJPROJ2/Plant/Saopan_result/NJPROJ1_10M /NJPROJ2/Plant/Saopan_result/
