#!/bin/bash
#########################################################################
# File Name: updateScanResult.sh
# Author: leiyang
# mail: leiyang@novogene.com
# Created Time: Mon 16 Apr 2018 10:21:21 AM CST
#########################################################################

export LC_ALL=
export LANG='en_US.utf8'
export TZ='Asia/Shanghai'

source /opt/gridengine/default/common/settings.sh


file=$1
outdir=$2
PWD=$outdir

cd $PWD

basename=`basename $file`

mkdir -p $PWD/$basename.cut
date=`date +"%Y%m%d"`

# split 
split --verbose -a 5 -d -l 1000  $file  $PWD/$basename.cut/ | perl -pe 's/.* //; s/^.|.$//g' > $PWD/$basename.cut.list
for name in `cat $PWD/$basename.cut.list`; do echo "perl -lane 'print if(-f \$F[2])' $name > $name.update" ; done  > $PWD/$basename.$date.cmd

# run
/NJPROJ2/Plant/zhangwenlin/Cluster_management/saopan/script/Software/qsub_batch --clean $PWD/$basename.$date.cmd

# merge result
cat /dev/null > $PWD/$basename.$date
for name in `cat $PWD/$basename.cut.list`; do cat  $name.update >> $PWD/$basename.$date; done 

# link 
[ -f  $PWD/$basename ]  && unlink $PWD/$basename
ln -s $PWD/$basename.$date $PWD/$basename 

