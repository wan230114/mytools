#!/bin/bash
#########################################################################
# File Name: updateScanResult.sh
# Author: leiyang
# mail: leiyang@novogene.com
# Created Time: Mon 16 Apr 2018 10:21:21 AM CST
#########################################################################

export LC_ALL=
export LANG='en_US.utf8'

file=$1
basename=`basename $file`
mkdir -p $basename.cut
date=`date +"%Y%m%d"`

# split 
split --verbose -a 5 -d -l 1000  $file  $PWD/$basename.cut/ | perl -pe 's/.* //; s/^.|.$//g' > $basename.cut.list
for name in `cat $basename.cut.list`; do echo "perl -lane 'print if(-f \$F[2])' $name > $name.update" ; done  > $basename.$date.cmd

# run
/NJPROJ2/Plant/users/wangyayun/Cluster_management/script/Software/qsub_batch --clean $basename.$date.cmd

# merge result
cat /dev/null > $basename.$date
for name in `cat $basename.cut.list`; do cat  $name.update >> $basename.$date; done 

