/NJPROJ2/Plant/plant_bs_share/software/anaconda2/bin/python /NJPROJ2/Plant/users/wangyayun/Cluster_management/script/geShellsForGettingFilesInfo.py --cfg ./scan_groups_js_plant.cfg
