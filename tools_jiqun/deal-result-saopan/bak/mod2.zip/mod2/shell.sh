# 进入每个目录下面去运行geShell
cat saopan.list |xargs -i sh -c "echo;echo === {} ===;echo;cd {}; sh geShell.sh"

# 进入每个目录投递扫盘
cat saopan.list |xargs -i sh -c "echo;echo === {} ===;echo;cd {}; nohup sh work.sh && python /NJPROJ2/Plant/chenjun/mytools/sendmail.py 1170101471@qq.com -c {}扫盘结束 &"
