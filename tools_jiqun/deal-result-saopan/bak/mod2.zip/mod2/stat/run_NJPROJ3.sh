path3=../NJPROJ3_saopan

mkdir tmp result 2>/dev/null

echo NJ3.1-Business-start && for name in $path3/scan/01.scan_results/02.formatted_results_from_scan_shell_out/Business/*;do awk '{if($5~/G/){$5=$5*1024*1024*1024}; if($5~/M/){$5=$5*1024*1024}; if($5~/K/){$5=$5*1024} ; printf "%s\t%d\t%s\t%s\n",$3,$5,$9,$6}' $name|awk '$2>10*1024*1024' ;done >tmp/NJPROJ3_10M.1 && echo NJ3.1-Business-ok &

echo NJ3.2-Assembly-start && for name in $path3/scan/01.scan_results/02.formatted_results_from_scan_shell_out/Assembly/*;do awk '{if($5~/G/){$5=$5*1024*1024*1024}; if($5~/M/){$5=$5*1024*1024}; if($5~/K/){$5=$5*1024} ; printf "%s\t%d\t%s\t%s\n",$3,$5,$9,$6}' $name|awk '$2>10*1024*1024' ;done >tmp/NJPROJ3_10M.2 && echo NJ3.2-Assembly-ok &

wait

cat tmp/NJPROJ3_10M.1 tmp/NJPROJ3_10M.2 >result/NJPROJ3_10M
