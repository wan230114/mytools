path1=../NJPROJ1_saopan

mkdir tmp result 2>/dev/null

echo NJ1.1-User-start && for name in $path1/scan/01.scan_results/02.formatted_results_from_scan_shell_out/User/*;do awk '{if($5~/G/){$5=$5*1024*1024*1024}; if($5~/M/){$5=$5*1024*1024}; if($5~/K/){$5=$5*1024} ; printf "%s\t%d\t%s\t%s\n",$3,$5,$9,$6}' $name|awk '{if($2>10000000){print $0}}' ;done >tmp/NJPROJ1_10M.1 && echo NJ1.2-User-ok &

echo NJ1.2-RESEQ-start && for name in $path1/scan/01.scan_results/02.formatted_results_from_scan_shell_out/RESEQ/* ;do awk '{if($5~/G/){$5=$5*1024*1024*1024}; if($5~/M/){$5=$5*1024*1024}; if($5~/K/){$5=$5*1024} ; printf "%s\t%d\t%s\t%s\n",$3,$5,$9,$6}' $name |awk '{if($2>10000000){print $0}}';done >tmp/NJPROJ1_10M.2 && echo NJ1.2-RESEQ-ok &

wait

cat tmp/NJPROJ1_10M.1 tmp/NJPROJ1_10M.2 >result/NJPROJ1_10M
