path2=../NJPROJ2_saopan

mkdir tmp result 2>/dev/null

echo NJ2.1-Assembly-start && for name in $path2/scan/01.scan_results/02.formatted_results_from_scan_shell_out/Assembly/* ;do  awk '{if($5~/G/){$5=$5*1024*1024*1024}; if($5~/M/){$5=$5*1024*1024}; if($5~/K/){$5=$5*1024} ; printf "%s\t%d\t%s\t%s\n",$3,$5,$9,$6}' $name |awk '{if($2>10000000){print $0}}';done >tmp/NJPROJ2_10M.1 && echo NJ2.1-Assembly-ok &

echo NJ2.2-Script-start   && for name in $path2/scan/01.scan_results/02.formatted_results_from_scan_shell_out/Script/* ;do  awk '{if($5~/G/){$5=$5*1024*1024*1024}; if($5~/M/){$5=$5*1024*1024}; if($5~/K/){$5=$5*1024} ; printf "%s\t%d\t%s\t%s\n",$3,$5,$9,$6}' $name|awk '{if($2>10000000){print $0}}';done >tmp/NJPROJ2_10M.2 && echo NJ2.2-Script-ok &

echo NJ2.3-Projects-start && for name in $path2/scan/01.scan_results/02.formatted_results_from_scan_shell_out/Projects/* ;do  awk '{if($5~/G/){$5=$5*1024*1024*1024}; if($5~/M/){$5=$5*1024*1024}; if($5~/K/){$5=$5*1024} ; printf "%s\t%d\t%s\t%s\n",$3,$5,$9,$6}' $name|awk '{if($2>10000000){print $0}}';done >tmp/NJPROJ2_10M.3 && echo NJ2.3-Projects-ok &

wait

cat tmp/NJPROJ2_10M.1 tmp/NJPROJ2_10M.2 tmp/NJPROJ2_10M.3 >result/NJPROJ2_10M
