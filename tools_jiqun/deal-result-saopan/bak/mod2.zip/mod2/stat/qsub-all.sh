qsub -cwd -l vf=4g,p=4 -q plant.q all-do.sh
