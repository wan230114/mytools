sh run_NJPROJ1.sh &
sh run_NJPROJ2.sh &
sh run_NJPROJ3.sh &
wait
python /NJPROJ2/Plant/chenjun/mytools/sendmail.py 1170101471@qq.com -c "南京扫盘统计完毕！"
