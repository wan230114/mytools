/NJPROJ2/Plant/plant_bs_share/software/anaconda3/bin/python3 /NJPROJ2/Plant/zhangwenlin/Cluster_management/saopan/script/geShellsForGettingFilesInfo.py --cfg ./scan_groups_js_plant.cfg
