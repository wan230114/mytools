import sys
import os
import traceback
import requests
import collections
from multiprocessing import Pool
from bs4 import BeautifulSoup
# 准备好list输入即可下载


def gethtml_data(foname, keyword, wuzhong, gene_name, gene_html):
    try:
        res_data = requests.get(gene_html)
        bs_data = BeautifulSoup(res_data.text, 'html.parser')
        L_all = bs_data.find_all('tr')
        for i, text in enumerate(L_all):
            if '<nobr>AA seq</nobr>' in str(text):
                tag_pp = text
            if '<nobr>NT seq</nobr>' in str(text):
                tag_aa = text
        s_pep = '>%s  %s  %s  %s' % (gene_name, foname, keyword,
                                     tag_pp.text.replace(' seq\n', 'seq '))
        s_cds = '>%s  %s  %s  %s' % (gene_name, foname, keyword,
                                     tag_aa.text.replace(' seq\n', 'seq '))
        # print(s_pep)
        # print(s_cds)
        D = {'cds': s_cds, 'pep': s_pep}
        print('-->', wuzhong, gene_name, gene_html)
        for key in D:
            fo_fa = os.path.join('Download', '%s_%s_%s_%s.%s' % (
                foname, keyword.replace(':', ''),
                wuzhong, gene_name, key))
            with open(fo_fa, 'w') as fo:
                fo.write(D[key])
                # print('[file writed success: %s]' % fo_fa)
    except Exception:
        traceback.print_exc()


def gethtml(foname, keyword, L_wuzhong):
    # 获取数据
    html_main = "https://www.kegg.jp"
    url = '%s/dbget-bin/www_bget?%s' % (html_main, keyword)
    print(url)
    res = requests.get(url)  # print(res.text)
    # 解析数据
    bs = BeautifulSoup(res.text, 'html.parser')
    L_all = bs.find_all('tr')  # [print(i, '\n', x) for i, x in enumerate(L_all)]
    tag_Genes = [text for text in L_all if '<nobr>Genes</nobr>' in str(text)][-1]
    tag_table = tag_Genes.find_all('table')
    D_wuzhong_num = collections.OrderedDict([[x, 0] for x in L_wuzhong])
    p = Pool(10)
    for wuzhong in L_wuzhong:
        print(wuzhong)
        for tag in tag_table:
            # print(tag)
            if wuzhong in str(tag):
                for tag_href in tag.find_all('a'):
                    D_wuzhong_num[wuzhong] += 1
                    gene_name = tag_href.text
                    gene_html = html_main + tag_href['href']
                    # gethtml_data(foname, keyword, wuzhong, gene_name, gene_html)
                    p.apply_async(gethtml_data, args=(
                        foname, keyword, wuzhong, gene_name, gene_html))
        print(wuzhong, '--', D_wuzhong_num[wuzhong])
    p.close()
    p.join()
    return D_wuzhong_num


def dealfile(fi_list):
    L = []
    with open(fi_list) as fi:
        for line in fi:
            Lline = line.strip().split('\t')
            foname = Lline[0]
            keyword = Lline[1]
            L_wuzhong = Lline[2:]
            # yield foname, keyword, L_wuzhong
            L.append([foname, keyword, L_wuzhong])
    return L


def fmain(fi_list):
    try:
        os.mkdir('Download')
    except Exception:
        print('Download文件夹已存在')
    L_tongji = [['#name1', 'name2', 'wuzhong', 'Download_num']]
    for foname, keyword, L_wuzhong in dealfile(fi_list):
        print('\n' + foname, keyword, L_wuzhong)
        D_wuzhong_num = gethtml(foname, keyword, L_wuzhong)
        s_wuzhong = '\t'.join(['%s_%s' % (wuzhong, D_wuzhong_num[wuzhong])
                               for wuzhong in L_wuzhong])
        L_tongji.append([foname, keyword, s_wuzhong])
        # break
    with open('Download.log', 'w') as fo:
        for Lline in L_tongji:
            fo.write('\t'.join(Lline) + '\n')


def main():
    fi_list = sys.argv[1]
    fmain(fi_list)


if __name__ == '__main__':
    main()
