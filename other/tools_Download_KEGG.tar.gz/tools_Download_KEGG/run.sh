# 准备好输入文件all.list，即可在同级目录下下载序列于Download
python3 getKEGG.py all.list
